package redis

import (
	"blueself/models"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/go-redis/redis/v8"
)

func CreatePost(c *gin.Context, post_ID int64) (err error) {
	// 事务操作，利用pipeline
	pipeline := rdb.TxPipeline()

	// 帖子时间
	pipeline.ZAdd(c, GetRedisKey(KeyPostTimeZSet), &redis.Z{
		Score:  float64(time.Now().Unix()),
		Member: post_ID,
	})

	// 帖子分数
	pipeline.ZAdd(c, GetRedisKey(KeyPostScoreZset), &redis.Z{
		Score:  float64(time.Now().Unix()),
		Member: post_ID,
	})

	_, err = pipeline.Exec(c)
	return
}

func GetPostIDsInOrder(c *gin.Context,p *models.ParamPostList) ([]string, error) {
	// 从redis获取id
	// 1. 根据用户请求中携带的order的参数确定要查询的redis key
	key := GetRedisKey(KeyPostTimeZSet)
	if p.Order == models.OrderScore{
		key = GetRedisKey(KeyPostScoreZset)
	}
	// 2. 确定查询的索引起始点
	start := (p.Page-1) * p.Size
	end := start + p.Size - 1
	// 3. ZREVRANGE查询
	return rdb.ZRevRange(c, key, start, end).Result()
}

// GetPostVoteData 根据ids查询每篇帖子的投赞成票的数据
func GetPostVoteData(c *gin.Context,ids []string)(data []int64, err error){
	/* 方法一
	data = make([]int64, 0, len(ids))
	for _, id := range ids{
		key := GetRedisKey(KeyPostVotedZSetPrefix+id)
		// 查找key中分数是1的元素数量->统计每篇帖子的赞成票的数量
		v := rdb.ZCount(c, key,"1","1").Val()
		data = append(data, v)
	}
	return
	*/

	// 利用pipeline形式 一次发送多条命令，减少RTT
	pipeline := rdb.Pipeline()
	for _, id := range ids{
		key := GetRedisKey(KeyPostVotedZSetPrefix+id)
		pipeline.ZCount(c, key, "1", "1")
	}
	cmders, err := pipeline.Exec(c)
	if err != nil{
		return
	}
	data = make([]int64, 0, len(cmders))
	for _, cmder := range cmders{
		v := cmder.(*redis.IntCmd).Val()
		data = append(data, v)
	}
	return
}